<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<h2>choose your option:</h2>
<hr/>
<select id="selct1" name="selct1" onchange="populate('selct1','selct2')">
<option value=""></option>
<option value="test">test</option>
<option value="test1">test1</option>
<option value="test2">test2</option>
</select>
<hr/>
<h2>choose your option2:</h2>
<select id="selct2" name="selct2">
</select>
<hr/>
<script>

</body>
</html>
