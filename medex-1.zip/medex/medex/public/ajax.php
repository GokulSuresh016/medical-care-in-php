<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
if(isset($_POST['dept'])){
	$dept=$_POST['dept'];
	$sql="select * from tbl_register_doctor where doctor_department='$dept'";
	echo "<option>$dept</option>";
	$result=mysqli_query($con,$sql);
	foreach($result as $resultSingle){
		$name=$resultSingle['doctor_name'];
		$id=$resultSingle['doctor_id'];
		$array=array($id,$name);
		$data=implode("/",$array);
		echo "<option>$data</option>";
	}
}

?>