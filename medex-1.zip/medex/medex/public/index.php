<?php
include"../template/header.php";
include"../pages/banner.php";
include"../pages/service-and-appoiment.php";
include"../pages/doctors.php";
include"../template/footer.php";
?>
   <!-- Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Appointment Form</h4>
        </div>
        <div class="modal-body">
						<form action="#" >
							<div class="">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="First Name">
								</div>
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Last Name">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="" id="" class="form-control">
												<option value="">Select Your Services</option>
												<option value="">Neurology</option>
												<option value="">Cardiology</option>
												<option value="">Dental</option>
												<option value="">Ophthalmology</option>
												<option value="">Other Services</option>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Phone">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-calendar"></span></div>
										<input type="text" class="form-control appointment_date" placeholder="Date">
									</div>
								</div>
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-clock-o"></span></div>
										<input type="text" class="form-control appointment_time" placeholder="Time">
									</div>
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<textarea name="" id="" cols="30" rows="2" class="form-control" placeholder="Message"></textarea>
								</div>
							</div>
						</form>
					
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

