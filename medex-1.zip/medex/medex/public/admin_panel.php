<?php
include"../template/header.php";
include"../pages/admin_panel.php";
include"../template/footer.php";
if(isset($_GET['tableedit'],$_GET['edit'])){
?>	
<script>
$(window).on('load',function(){
        $('#exampleModal').modal('show');
    });
	 </script>
<?php
}	
?>
 
