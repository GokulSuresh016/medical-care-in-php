<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
$id=$_SESSION['id'];
 $sql="select * from tbl_appoinment where appoinment_doctor_id = '10';";
$result =mysqli_query($con,$sql);	
?>
<div class="row">
<div class=" col-md-12">
<h3 class="justify-content-center align-items-center" style="text-align:center;padding:10px;">ADMIN PANEL</h3>
<p class="tables" style="text-align:center;padding:5px">
</p>
</div>
</div>
<div class="row">
<div class="col-md-12  justify-content-center align-items-center" style="text-align:center;">
<table border="2" cellpadding="5">
<tr>
<td>Name</td>
<td>Date</td>
<td>Time</td>
<td>Number</td>
<td>Meassage</td>
</tr>
<?php 
foreach($result as $resultSingle)
{
?>
<tr>
<td><?php echo $resultSingle['appoinment_user_name'];?></td>
<td><?php echo $resultSingle['appoinment_date'];?></td>
<td><?php echo $resultSingle['appoinment_time'];?></td>
<td><?php echo $resultSingle['appoinment_number'];?></td>
<td><?php echo $resultSingle['appoinment_meassage'];?></td>
<tr>
<?php
}
?>
</table>
<br>
</div>
</div>
