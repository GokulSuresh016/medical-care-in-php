<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
if(isset($_GET['register'])){
	$table="tbl_doctor_login";
	?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50"style="padding:20px;">
				<form class="login100-form validate-form"style="padding:20px;" method="POST" action="">
					<span class="login100-form-title p-b-33" style="padding:20px;">
						Doctor Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz"style="padding:15px;">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required"style="padding:15px;">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20"style="padding:15px;">
						<button class="login100-form-btn" name="btn_login">
							Sign in
						</button>
					</div>

					<div class="text-center p-t-45 p-b-4">
						<span class="txt1">
							Are You A Registered User?
						</span>

						<a href="login.php" class="txt2 hov1"style="color:blue;">
							Sign In Here
						</a>
					</div>

					<div class="text-center">
						<span class="txt1">
							Create an account?
						</span>

						<a href="registration.php" class="txt2 hov1"style="color:blue;">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>	
	<?php	
}
else{
	$table="tbl_user_login";
	?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50"style="padding:20px;">
				<form class="login100-form validate-form"style="padding:20px;" method="POST" action="">
					<span class="login100-form-title p-b-33" style="padding:20px;">
						User Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz"style="padding:15px;">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required"style="padding:15px;">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20"style="padding:15px;">
						<button class="login100-form-btn" name="btn_login">
							Sign in
						</button>
					</div>

					<div class="text-center p-t-45 p-b-4">
						<span class="txt1">
							Are You A Registered Doctor?
						</span>

						<a href="login.php?register" class="txt2 hov1"style="color:blue;">
							Sign In Here
						</a>
					</div>

					<div class="text-center">
						<span class="txt1">
							Create an account?
						</span>

						<a href="registration.php" class="txt2 hov1"style="color:blue;">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php
}
if(isset($_POST['btn_login']))
{
	
 $query="SELECT * FROM $table";
$result=mysqli_query($con,$query);
$username=$_POST['username'];
$pass=$_POST['pass'];
foreach($result as $resultSingle)
{
	if(($resultSingle['login_username'] == $username && $resultSingle['login_password'] == $pass))
	{
		$cat = $resultSingle['login_category'];
			 $sql="select * from $table where login_username = '$username' && login_password = '$pass';";
			$res=mysqli_query($con,$sql);
			foreach($res as $resSingle)
			{
			     $id = $resSingle['login_id'];
				 $_SESSION['type']=$cat;
				 $_SESSION['id']=$id;
if($cat == 'doctor'){				
					echo ' <script> swal("Success!", "Signed In Successfully!", "success").then(function(){window.location="doctor-view-appointments.php"}); </script>';
			}
			else{
				echo ' <script> swal("Success!", "Signed In Successfully!", "success").then(function(){window.location="index.php"}); </script>';
	
			}
			}
		
	}
}

}
?>
