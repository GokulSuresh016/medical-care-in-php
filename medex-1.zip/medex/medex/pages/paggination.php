<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	$query="SELECT * FROM tbl_gallery";
  $result=mysqli_query($con,$query);
    $total=mysqli_num_rows($result);
   $totalpage=ceil($total/4);
   $num=1;
  ?>
<div class="row mt-5">
  <div class="col text-center">
    <div class="block-27">
      <ul>
        <li><a href="#">&lt;</a></li>
				<?php
	  while($num <= $totalpage){
	?>
        <li class="active"><a href="gallery.php?page=<?php echo $num?>"><span><?php echo $num ?></span></a></li>
		      <?php
		$num=$num+1;
   }
		?>
        <li><a href="#">&gt;</a></li>
      </ul>
    </div>
  </div>
</div>
<br>