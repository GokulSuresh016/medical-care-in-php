<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
 $query="SELECT * FROM tbl_blog WHERE blog_id ='".$_GET['id']."'";
  $result=mysqli_query($con,$query);
   while($row = mysqli_fetch_array($result)){
  ?>
<section class="ftco-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 ftco-animate">
	   <h2 class="mb-3 mt-5"><?php echo $row['blog_title']; ?></h2>
        <p><?php echo $row['blog_description_short']; ?><p>
          <img src="../images/<?php echo $row['blog_image']; ?>" alt="" class="img-fluid">
   </p><?php echo $row['blog_description_long']; }?></p>
        <div class="tag-widget post-tag-container mb-5 mt-5">
          <div class="tagcloud">
            <a href="#" class="tag-cloud-link">Life</a>
            <a href="#" class="tag-cloud-link">Sport</a>
            <a href="#" class="tag-cloud-link">Tech</a>
            <a href="#" class="tag-cloud-link">Travel</a>
          </div>
        </div>
		 </div>
		  
		<div class="col-lg-4 sidebar ftco-animate">
        <div class="sidebar-box">
          <form action="#" class="search-form">
            <div class="form-group">
              <span class="icon icon-search"></span>
              <input type="text" class="form-control" placeholder="Type a keyword and hit enter">
            </div>
          </form>
        </div>
        <div class="sidebar-box ftco-animate">
         <h3 class="heading-sidebar">Categories</h3>
         <ul class="categories">
          <li><a href="#">Ophthalmology <span>(12)</span></a></li>
          <li><a href="#">Neurology <span>(22)</span></a></li>
          <li><a href="#">Cardiology <span>(37)</span></a></li>
          <li><a href="#">Surgical <span>(42)</span></a></li>
          <li><a href="#">Dental Clinic <span>(42)</span></a></li>
          <li><a href="#">X-Ray <span>(42)</span></a></li>
          <li><a href="#">Nuclear Magnetic <span>(42)</span></a></li>
        </ul>
      </div>

      <div class="sidebar-box ftco-animate">
        <h3 class="heading-sidebar">Recent Blog</h3>
        <div class="block-21 mb-4 d-flex">
          <a class="blog-img mr-4" style="background-image: url(../images/image_1.jpg);"></a>
          <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about the blind texts</a></h3>
            <div class="meta">
              <div><a href="#"><span class="icon-calendar"></span> Aug. 12, 2020</a></div>
              <div><a href="#"><span class="icon-person"></span> Admin</a></div>
              <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
          </div>
        </div>
        <div class="block-21 mb-4 d-flex">
          <a class="blog-img mr-4" style="background-image: url(../images/image_2.jpg);"></a>
          <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about the blind texts</a></h3>
            <div class="meta">
              <div><a href="#"><span class="icon-calendar"></span> Aug. 12, 2020</a></div>
              <div><a href="#"><span class="icon-person"></span> Admin</a></div>
              <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
          </div>
        </div>
        <div class="block-21 mb-4 d-flex">
          <a class="blog-img mr-4" style="background-image: url(../images/image_3.jpg);"></a>
          <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control about the blind texts</a></h3>
            <div class="meta">
              <div><a href="#"><span class="icon-calendar"></span> Aug. 12, 2020</a></div>
              <div><a href="#"><span class="icon-person"></span> Admin</a></div>
              <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
          </div>
        </div>
      </div>

      <div class="sidebar-box ftco-animate">
        <h3 class="heading-sidebar">Tag Cloud</h3>
        <div class="tagcloud">
          <a href="#" class="tag-cloud-link">house</a>
          <a href="#" class="tag-cloud-link">medical</a>
          <a href="#" class="tag-cloud-link">health</a>
          <a href="#" class="tag-cloud-link">medicine</a>
          <a href="#" class="tag-cloud-link">surgeon</a>
          <a href="#" class="tag-cloud-link">heart</a>
          <a href="#" class="tag-cloud-link">neuron</a>
          <a href="#" class="tag-cloud-link">system</a>
        </div>
      </div>

    
    </div>

  </div>
  <div class="row">
			<div class="col-md-12">
			<div class="carousel-testimony owl-carousel ftco-owl">
				
					<div class="staff">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/doc-1.jpg);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. Lloyd Wilson</h3>
							<span class="position mb-2">Neurologist</span>
							<div class="faded">
								<p>I am an ambitious workaholic, but apart from that, pretty simple person.</p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-google"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="staff">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/doc-2.jpg);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. Rachel Parker</h3>
							<span class="position mb-2">Ophthalmologist</span>
							<div class="faded">
								<p>I am an ambitious workaholic, but apart from that, pretty simple person.</p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-google"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="staff">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/doc-3.jpg);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. Ian Smith</h3>
							<span class="position mb-2">Dentist</span>
							<div class="faded">
								<p>I am an ambitious workaholic, but apart from that, pretty simple person.</p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-google"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
					</div>
				<div class="staff">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/doc-4.jpg);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. Alicia Henderson</h3>
							<span class="position mb-2">Pediatrician</span>
							<div class="faded">
								<p>I am an ambitious workaholic, but apart from that, pretty simple person.</p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-google"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
					</div>
				<div class="staff ">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/doc-1.jpg);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. Lloyd Wilson</h3>
							<span class="position mb-2">Neurologist</span>
							<div class="faded">
								<p>I am an ambitious workaholic, but apart from that, pretty simple person.</p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-twitter"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-facebook"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-google"></span></a></li>
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"></span></a></li>
								</ul>
							</div>
						</div>
					</div>
				
				</div>
		</div>
			</div>
  
  
  
</div>
</section>