<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	$query="SELECT * FROM tbl_basic_details;";
  $result=mysqli_query($con,$query);
   while($row = mysqli_fetch_array($result)){
  ?>
<section class="ftco-section contact-section">
  <div class="container">
    <div class="row d-flex contact-info mb-5">
      <div class="col-md-6 col-lg-3 d-flex ftco-animate">
       <div class="align-self-stretch box p-4 text-center bg-light">
        <div class="icon d-flex align-items-center justify-content-center">
         <span class="flaticon-flag"></span>
       </div>
       <h3 class="mb-4">Address</h3>
       <p><?php echo $row['basic_location']; ?></p>
     </div>
   </div>
   <div class="col-md-6 col-lg-3 d-flex ftco-animate">
     <div class="align-self-stretch box p-4 text-center bg-light">
      <div class="icon d-flex align-items-center justify-content-center">
       <span class="flaticon-phone-call"></span>
     </div>
     <h3 class="mb-4">Contact Number</h3>
     <p><a href="tel://1234567920"><?php echo $row['basic_number']; ?></a></p>
   </div>
 </div>
 <div class="col-md-6 col-lg-3 d-flex ftco-animate">
   <div class="align-self-stretch box p-4 text-center bg-light">
    <div class="icon d-flex align-items-center justify-content-center">
     <span class="flaticon-paper-plane"></span>
   </div>
   <h3 class="mb-4">Email Address</h3>
   <p><a href="mailto:info@yoursite.com"><?php echo $row['basic_mail']; } ?></a></p>
 </div>
</div>
<div class="col-md-6 col-lg-3 d-flex ftco-animate">
 <div class=" box p-4 text-center bg-light">
  <div class="icon d-flex align-items-center justify-content-center">
   <span class="flaticon-world-wide-web-on-grid"></span>
 </div>
 <h3 class="mb-4">Website</h3>
 <p><a href="#">yoursite.com</a></p>
</div>
</div>
</div>
<div class="row no-gutters block-9">
  <div class="col-md-6 order-md-last d-flex">
    <form action="#" class="bg-light p-5 contact-form">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Your Name">
      </div>
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Your Email">
      </div>
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Subject">
      </div>
      <div class="form-group">
        <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
      </div>
      <div class="form-group">
        <input type="submit" value="Send Message" class="btn btn-secondary py-3 px-5">
      </div>
    </form>
    
  </div>

  <div class="col-md-6 d-flex">
   <div id="map" class="bg-white"></div>
 </div>
</div>
</div>
</section>