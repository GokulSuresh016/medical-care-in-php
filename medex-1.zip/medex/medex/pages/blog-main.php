<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	$query="SELECT * FROM tbl_blog;";
  $result=mysqli_query($con,$query);
   while($row = mysqli_fetch_array($result)){
	   $des=$row['blog_description_short']; 
	   $substr=substr($des,0,100);
  ?>
<section class="ftco-section bg-light">
  <div class="container-fluid px-md-5">
    <div class="row d-flex">
      <div class="col-lg-4 ftco-animate">
        <div class="blog-entry">
          <a href="blog-single.php" class="block-20" style="background-image: url('../images/<?php echo $row['blog_image']; ?>');">
          </a>
          <div class="d-flex">
           <div class="meta pt-3 text-right pr-2">
            <div><a href="#"><span class="fa fa-calendar mr-2"></span><?php echo $row['blog_posted_date']; ?></a></div>
            <div><a href="#"><span class="fa fa-user mr-2"></span><?php echo $row['blog_whom']; ?></a></div>
            <div><a href="#" class="meta-chat"><span class="fa fa-comment mr-2"></span> 3</a></div>
          </div>
          <div class="text d-block">
           <h3 class="heading"><a href="#"><?php echo $row['blog_title']; ?></a></h3>
   <p><?php echo $substr ; ?></p>
   <p><a href="blog-single.php?id=<?php echo $row['blog_id']; }?>" class="btn btn-secondary btn-outline-secondary py-2 px-3">Read more</a></p>
         </div>
       </div>
     </div>
   </div>
</div>
<div class="row mt-5">
  <div class="col text-center">
    <div class="block-27">
      <ul>
        <li><a href="#">&lt;</a></li>
        <li class="active"><span>1</span></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">5</a></li>
        <li><a href="#">&gt;</a></li>
      </ul>
    </div>
  </div>
</div>
</div>
</section>