<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
 if(isset($_GET['page']))
 {
	 $page=$_GET['page'];
 }
 else
 {
	 $page=1;
 }
 $limit=4;
 $start=($page-1)*$limit;
	$query="SELECT * FROM tbl_gallery LIMIT $start,$limit";
  $result=mysqli_query($con,$query);	   
  ?>
<section class="ftco-section">
 <div class="container">

  <div class="row">
   <?php
 while($row = mysqli_fetch_array($result)){
 ?>
   <div class="col-md-3">
   <a href="../images/<?php echo $row['gallery_image']; ?>" class="image-popup img gallery ftco-animate" style="background-image: url(../images/<?php echo $row['gallery_image'];  ?>);">
     <span class="overlay"></span>
   </a>
 </div>
 <?php
   }
?>
</div>

</div>
</section>
