<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
if(isset($_POST['banner_save_button']))
{
	$filename=$_FILES['gallery_image']['name'];	
    $tempname=$_FILES['gallery_image']['tmp_name'];
$folder="../images/".$filename;
if(move_uploaded_file($tempname,$folder)){
		 $query="insert into tbl_banner(banner_image) values ('$filename');";
$result=mysqli_query($con,$query);
	 }
}
 elseif(isset($_POST['basic_save_button']))
{
	$email=$_POST['basic_mail'];	
	$phone=$_POST['basic_phone'];
	$location=$_POST['basic_location'];
	$query="INSERT INTO tbl_basic_details(basic_mail,basic_number,basic_location) VALUES  ('$email','$phone','$location');";
 $result=mysqli_query($con,$query); 
}
 elseif(isset($_POST['blog_save_button']))
{
	$filename=$_FILES['blog_image']['name'];	
    $tempname=$_FILES['blog_image']['tmp_name'];
    $folder="../images/".$filename;
	$title=$_POST['blog_title'];	
	$des_short=$_POST['blog_des_short'];
	$des_long=$_POST['blog_des_long'];
	if(move_uploaded_file($tempname,$folder)){
	$query="insert into tbl_blog(blog_image,blog_title,blog_description_short,blog_description_long) values ('$filename','$title','$des_short','$des_long');";
$result=mysqli_query($con,$query); 
	}
	else{
		echo "failed";
	}
}
elseif(isset($_POST['gallery_save_button']))
{
		$filename=$_FILES['gallery_image']['name'];	
    $tempname=$_FILES['gallery_image']['tmp_name'];
$folder="../images/".$filename;
if(move_uploaded_file($tempname,$folder)){
		 $query="insert into tbl_gallery(gallery_image) values ('$filename');";
$result=mysqli_query($con,$query);
	 }
}
 elseif(isset($_POST['service_save_button']))
{
	$service_icon=$_POST['service_icon'];
	$service_icon;	
	$service_title=$_POST['service_title'];
	$service_description=$_POST['service_description'];
	$query="insert into tbl_services(service_icon,service_title,service_description) values ('$service_icon','$service_title','$service_description');";
$result=mysqli_query($con,$query); 
}
?>
<section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-2 bg-light">
		<div class="container">
			<div class="row d-flex">
<div class="col-md-5 d-flex">
					<div class="appointment-wrap p-4 p-lg-5 d-flex align-items-center">
						<form action="" class="appointment-form ftco-animate" method="POST">
							<h3 class="justify-content-center">Appointment Form</h3>
							<div class="">
								<div class="form-group">
								<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="table" id="table" class="form-control">
											<option value="Select Your Table">Select Your Table</option>	
											<option value="tbl_banner">tbl_banner</option>
											<option value="tbl_basic_details">tbl_basic_details</option>
											<option value="tbl_blog">tbl_blog</option>
											<option value="tbl_gallery">tbl_gallery</option>
											<option value="tbl_services">tbl_services</option>
											</select>
										</div>
									</div>	
								</div>
								<div class="form-group">
									<input type="submit" name="next_button" id="appointment_button" value="Next" class="btn btn-secondary py-3 px-4">
								</div>
								</div>
								</form>
							</div>
					</div>
					<div class="col-md-7 d-flex">
					<?php
					$table="default";
					if(isset($_POST['next_button'])){
						 $table=$_POST['table'];
					}
					if($table == 'tbl_banner')
					{
					?>
					<form action="" class="appointment-form ftco-animate" method="POST" enctype="multipart/form-data">
					<br>
					<div class="">
								<div class="form-group">
									<input name="gallery_image" type="file" class="form-control" placeholder="">
								</div>
								<div class="form-group">
									<input type="submit" name="banner_save_button" id="banner_save_button" value="Save" class="btn btn-secondary py-3 px-4">
								</div>
					
							</div>
					</form>
					<?php
					}elseif($table == 'tbl_basic_details')
					{
					?>
					<form action="" class="appointment-form ftco-animate" method="POST">
					<br>
					<div class="">
								<div class="form-group">
									<input name="basic_mail" type="text" class="form-control" placeholder="e-mail">
								</div>
								<div class="form-group">
									<input name="basic_phone" type="text" class="form-control" placeholder="phone">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<input name="basic_location" type="text" class="form-control" placeholder="location">
								</div>
								<div class="form-group">
									<input type="submit" name="basic_save_button" id="basic_save_button" value="Save" class="btn btn-secondary py-3 px-4">
								</div>
							</div>
					</form>
					<?php
					}elseif($table == 'tbl_blog')
					{
					?>
					<form action="" class="appointment-form ftco-animate" method="POST"  enctype="multipart/form-data">
					<br>
					<div class="">
								<div class="form-group">
									<input name="blog_image" type="file" class="form-control" placeholder="">
								</div>
								<div class="form-group">
									<input name="blog_title" type="text" class="form-control" placeholder="blog-title">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<input name="blog_des_short" type="text" class="form-control" placeholder="blog-description-short">
								</div>
								<div class="form-group">
									<input name="blog_des_long" type="text" class="form-control" placeholder="blog-description-long">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<input type="submit" name="blog_save_button" id="appointment_button" value="Save" class="btn btn-secondary py-3 px-4">
								</div>
					
							</div>
					</form>
					<?php
					}elseif($table == 'tbl_gallery')
					{
					?>
					<form action="" class="appointment-form ftco-animate" method="POST"  enctype="multipart/form-data">
					<br>
					<div class="">
								<div class="form-group">
									<input name="gallery_image" type="file" class="form-control" placeholder="">
								</div>
								<div class="form-group">
									<input type="submit" name="gallery_save_button" id="appointment_button" value="Save" class="btn btn-secondary py-3 px-4">
								</div>
							</div>
					</form>
					<?php
					}elseif($table == 'tbl_services')
					{
					?>
					<form action="" class="appointment-form ftco-animate" method="POST">
					<br>
					<div class="">
								<div class="form-group">
									<input name="service_icon" type="text" class="form-control" placeholder="service-icon">
								</div>
								<div class="form-group">
									<input name="service_title" type="text" class="form-control" placeholder="service_title">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<input name="service_description" type="text" class="form-control" placeholder="service-description">
								</div>
								<div class="form-group">
									<input type="submit" name="service_save_button" id="appointment_button" value="Save" class="btn btn-secondary py-3 px-4">
								</div>
					
							</div>
					</form>
					<?php
					}
					else
					{
					echo "please select a cat?";	
					}
					?>
				</div>
					</div>
				</div>
				</section>