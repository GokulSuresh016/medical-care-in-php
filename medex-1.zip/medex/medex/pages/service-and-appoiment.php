<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
if(isset($_POST['appointment_button'])){
	
	$name=$_POST['fname'];
	$dept=$_POST['dept'];
	$doctor=$_POST['doctor'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$number=$_POST['phone'];
	$meassage=$_POST['meassage'];
	$userid="test1";
	$array = explode("/",$doctor);
	$doctor_id = $array[0];
	$doctor_name = $array[1];
	$sql="INSERT into tbl_appoinment(appoinment_user_name,appoinment_department,appoinment_date,appoinment_time,appoinment_number,appoinment_meassage,appoinment_user_id,appoinment_doctor_id,appoinment_doctor_name) values ('$name','$dept','$date','$time','$number','$meassage','$userid','$doctor_id','$doctor_name');";
	$result=mysqli_query($con,$sql);
}
?>
<section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-2 bg-light">
		<div class="container">
			<div class="row d-flex">
				<div class="col-md-7 py-5">
					<div class="py-lg-5">
						<div class="row justify-content-center pb-5">
							<div class="col-md-7 heading-section ftco-animate">
								<h2 class="mb-3">Our Services <span>Medex</span></h2>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-ambulance"></span></div>
									<div class="media-body pl-md-4">
										<h3 class="heading mb-3">Emergency Help</h3>
										<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-ophthalmologist"></span></div>
									<div class="media-body pl-md-4">
										<h3 class="heading mb-3">Qualified Doctors</h3>
										<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-flag"></span></div>
									<div class="media-body pl-md-4">
										<h3 class="heading mb-3">Location &amp; Directions</h3>
										<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</div>
								</div>      
							</div>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-stethoscope"></span></div>
									<div class="media-body pl-md-4">
										<h3 class="heading mb-3">Medical Treatment</h3>
										<p>A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
									</div>
								</div>      
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-5 d-flex">
					<div class="appointment-wrap p-4 p-lg-5 d-flex align-items-center">
						<form action="" class="appointment-form ftco-animate" method="POST">
							<h3 class="justify-content-center">Appointment Form</h3>
							<div class="">
								<div class="form-group">
									<input name="fname" type="text" class="form-control" placeholder="First Name">
								</div>
								<div class="form-group"> 
									<input  name="lname" type="text" class="form-control" placeholder="Last Name">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="dept" id="dept" class="form-control">
												<option value="">Select Your Services</option>
												<option value="test dept1">test dept1</option>
												<option value="test dept">test dept</option>
												<option value="demo">demo</option>
												<option value="">Ophthalmology</option>
												<option value="">Other Services</option>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="doctor" id="doctor" class="form-control">
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-calendar"></span></div>
										<input name="date" type="text" class="form-control appointment_date" placeholder="Date">
									</div>
								</div>
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-clock-o"></span></div>
										<input name="time" type="text" class="form-control appointment_time" placeholder="Time">
									</div>
								</div>
							</div>
							<div class="">
							<div class="form-group">
									<input name="phone" type="text" class="form-control" placeholder="Phone">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<textarea name="meassage" id="meassage" cols="30" rows="2" class="form-control" placeholder="Message"></textarea>
								</div>
								<div class="form-group">
									<input type="submit" name="appointment_button" id="appointment_button" value="Appointment" class="btn btn-secondary py-3 px-4">
								</div>
							</div>	
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
