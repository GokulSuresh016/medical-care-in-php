<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	
  
if(isset($_POST['register'])){
	$type=$_POST['type'];
	if($type == "Doctor"){	
	$name=$_POST['name'];
	$username=$_POST['username'];
	$dept=$_POST['dept'];
	$hospital=$_POST['hospital'];
	$password=$_POST['password'];
	$filename=$_FILES['image']['name'];	
    $tempname=$_FILES['image']['tmp_name'];
$folder="../images/".$filename;
$query="insert into tbl_register_doctor(doctor_name,doctor_username,doctor_password,doctor_image,doctor_department,doctor_hospital) values ('$name','$username','$password','$filename','$dept','$hospital');";
$result=mysqli_query($con,$query);
$sql="INSERT INTO tbl_doctor_login(login_username,login_password,login_category) VALUES('$username','$password','doctor');";
	 $result=mysqli_query($con,$sql);
if(move_uploaded_file($tempname,$folder)){
		  "uploaded";
	 }
	 else 
	 {
		  "failed";
	 }	
	}
	elseif($type == "Common User"){
		$name=$_POST['name'];
	$username=$_POST['username'];
	$hospital=$_POST['hospital'];
	$password=$_POST['password'];
	$filename=$_FILES['image']['name'];	
    $tempname=$_FILES['image']['tmp_name'];
$folder="../images/".$filename;
$query="insert into tbl_register_user(user_name,user_username,user_password,user_image,user_location) values ('$name','$username','$password','$filename','$hospital');";
$result=mysqli_query($con,$query);
$sql="INSERT INTO tbl_user_login(login_username,login_password,login_category) VALUES('$username','$password','user');";
	 $result=mysqli_query($con,$sql);
	 if(move_uploaded_file($tempname,$folder)){
		  "uploaded";
	 }
	 else 
	 {
		  "failed";
	 }	
	}
}
	?>
<div class="row no-gutters block-9">
<div class="col-md-6 d-flex order-md-last d-flex">
					<div class="appointment-wrap p-4 p-lg-5 d-flex align-items-center">
						<form action="" method="POST" enctype="multipart/form-data" class="appointment-form ftco-animate ">
							<h3 class="justify-content-center">Registration Form</h3>
							<div class="">
								<div class="form-group">
									<input  name="name" type="text" class="form-control" placeholder="Name">
								</div>
								<div class="form-group">
									<input  name="username" type="text" class="form-control" placeholder="User Name">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="type" id="type" class="form-control">
												<option value="">Select Who You Are</option>
												<option value="Common User">Common User</option>
												<option value="Doctor">Doctor</option>
											</select>
										</div>
									</div>
								</div>
			
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="dept" id="dept" class="form-control">
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-photo"></span></div>
										<input type="file"  name="image" id="image" class="form-control" placeholder="Image">
									</div>
								</div>
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-key"></span></div>
										<input name="password" type="password" class="form-control appointment_time" placeholder="password">
									</div>
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-hospital"></span></div>
										<input name="hospital" type="text" class="form-control appointment_time" placeholder="location">
									</div>
								</div>
								<div class="form-group">
									<input type="submit" name="register" value="Register" class="btn btn-secondary py-3 px-4">
								</div>
							</div>
						</form>
					</div>
				</div>
				</div>
				
			