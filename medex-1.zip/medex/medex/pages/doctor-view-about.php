<?php
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
$id=$_SESSION['id'];
$sql="select * from tbl_register_doctor where doctor_id = '10';";
$result=mysqli_query($con,$sql);
foreach($result as $resultSingle)
{
?>
<section class="ftco-section bg-light">
		<div class="container">
			<div class="row">
<div class="col-md-6 col-lg-6 ftco-animate"style="align-text:center;">
					<div class="staff">
						<div class="img-wrap d-flex align-items-stretch">
							<div class="img align-self-stretch" style="background-image: url(../images/<?php echo $resultSingle['doctor_image'];?>);"></div>
						</div>
						<div class="text text-center">
							<h3 class="mb-2">Dr. <?php echo $resultSingle['doctor_name'];?></h3>
<span class="position mb-2"><?php echo $resultSingle['doctor_department']; ?></span>
							<div class="faded">
								<p><?php echo $resultSingle['doctor_hospital'];?></p>
								<ul class="ftco-social text-center">
									<li class="ftco-animate"><a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-edit"></span></a></li>
									</ul>
							</div>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</section>
	<?php
	}
	?>