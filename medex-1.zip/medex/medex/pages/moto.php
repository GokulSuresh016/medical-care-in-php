	<section class="ftco-intro img" style="background-image: url(images/bg_3.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row justify-content-end">
				<div class="col-md-7">
					<h2>Your Health is Our Priority</h2>
					<p>We can manage your dream building A small river named Duden flows by their place</p>
					<p class="mb-0"><a href="#" class="btn btn-white px-4 py-3">Make An Appointment</a></p>
				</div>
			</div>
		</div>
	</section>