<?php
$flag=1;
$con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
if(isset($_POST['appointment_button'])){
	
	$name=$_POST['fname'];
	$dept=$_POST['dept'];
	$doctor=$_POST['doctor'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$number=$_POST['phone'];
	$meassage=$_POST['meassage'];
	$userid="test1";
	$array = explode("/",$doctor);
	$doctor_id = $array[0];
	$doctor_name = $array[1];
	$sql="INSERT into tbl_appoinment(appoinment_user_name,appoinment_department,appoinment_date,appoinment_time,appoinment_number,appoinment_meassage,appoinment_user_id,appoinment_doctor_id,appoinment_doctor_name) values ('$name','$dept','$date','$time','$number','$meassage','$userid','$doctor_id','$doctor_name');";
	$result=mysqli_query($con,$sql);
}
?>
<div class="row no-gutters block-9">
<div class="col-md-6 d-flex order-md-last d-flex">
					<div class="appointment-wrap p-4 p-lg-5 d-flex align-items-center">
						<form action="" class="appointment-form ftco-animate" method="POST">
							<h3 class="justify-content-center">Appointment Form</h3>
							<div class="">
								<div class="form-group">
									<input name="fname" type="text" class="form-control" placeholder="First Name">
								</div>
								<div class="form-group"> 
									<input  name="lname" type="text" class="form-control" placeholder="Last Name">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="dept" id="dept" class="form-control">
												<option value="">Select Your Services</option>
												<option value="test dept1">test dept1</option>
												<option value="test dept">test dept</option>
												<option value="demo">demo</option>
												<option value="">Ophthalmology</option>
												<option value="">Other Services</option>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="form-field">
										<div class="select-wrap">
											<div class="icon"><span class="fa fa-chevron-down"></span></div>
											<select name="doctor" id="doctor" class="form-control">
											</select>
										</div>
									</div>
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-calendar"></span></div>
										<input name="date" type="text" class="form-control appointment_date" placeholder="Date">
									</div>
								</div>
								<div class="form-group">
									<div class="input-wrap">
										<div class="icon"><span class="fa fa-clock-o"></span></div>
										<input name="time" type="text" class="form-control appointment_time" placeholder="Time">
									</div>
								</div>
							</div>
							<div class="">
							<div class="form-group">
									<input name="phone" type="text" class="form-control" placeholder="Phone">
								</div>
							</div>
							<div class="">
								<div class="form-group">
									<textarea name="meassage" id="meassage" cols="30" rows="2" class="form-control" placeholder="Message"></textarea>
								</div>
								<div class="form-group">
									<input type="submit" name="appointment_button" id="appointment_button" value="Appointment" class="btn btn-secondary py-3 px-4">
								</div>
							</div>	
						</form>
					</div>
				</div>
				<?php
				if($flag == 1)
				{
				$sql="select * from tbl_appoinment where appoinment_user_id = 'test1' ;";
				$result=mysqli_query($con,$sql);
				?>
				<div class="col-md-6 d-flex order-md-last d-flex">
				<h4 class="justify-content-center">Appointment Form Status</h4>
				<table border="solid">
					<tr>
					<td>appontment id</td>
					<td>appointment date</td>
					<td>appontment time</td>
					<td>appontment doctor</td>
					</tr>
					<?php
					foreach($result as $resultSingle)
				{
					?>
					<tr>
					<td><?php echo $resultSingle['appoinment_id'] ?></td>
					<td><?php echo $resultSingle['appoinment_date'] ?></td>
					<td><?php echo $resultSingle['appoinment_time'] ?></td>
					<td><?php echo $resultSingle['appoinment_doctor_name'] ?></td>
					</tr>
					<?php
				}
					?>
				</table>
				</div>
				<?php
				}
				?>
				</div>