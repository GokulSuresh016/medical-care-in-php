<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	 $query="SHOW TABLES";
   $result=mysqli_query($con,$query);
 if(isset($_GET['table'])){
	  $table=$_GET['table'];
 }
else
{
	$table="tbl_banner";
}	
if(isset($_GET['delete'])){
	echo $tabledelete=$_GET['tableedit'];
	echo $iddelete=$_GET['delete'];
	echo $table_iddelete=$_GET['table-id'];
	echo $query_delete="DELETE  FROM $tabledelete where $table_iddelete='$iddelete'";
	$result_update=mysqli_query($con,$query_delete);
		echo '<script> swal("Success!", "Deleted successfully!", "success").then(function(){window.location="../Public/admin_panel.php"});</script>';
}
if(isset($_GET['tableedit'],$_GET['edit'],$_GET['table-id'])){
	$table=$_GET['tableedit'];
	$id=$_GET['edit'];
	$table_id=$_GET['table-id'];
	?>
	 <div class="row data-toggle="modal" data-target="exampleModal"">
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	  <?php
	  $query1="SELECT * FROM $table WHERE $table_id = $id";
	$result=mysqli_query($con,$query1);
	foreach($result as $querySingle)
	{
		$query_column="SHOW COLUMNS FROM $table";
	$columns=mysqli_query($con,$query_column);
	foreach($columns as $columnsSingle)
	{
	?>
      <div class="modal-body">
	  <form action="" method="POST">
       <div class="form-group">
		 <br>
		        <label for="name"><?php echo $columnsSingle['Field'] ?></label>
                <input class="form-control"  type="text" name="name" value="<?php echo $querySingle[$columnsSingle['Field']]; ?>">
            </div>		
      </div>
	  <?php
	}
	}
	  ?>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="window.location.href='admin_panel.php'">Close</button>
        <button name="update" type="submit" class="btn btn-primary">Save changes</button>
      </div>
	  </form>
    </div>
  </div>
</div>
</div>
	
	<?php
}
else{
	echo "";
}
 ?>
<div class="row  bg-light">
<div class=" col-md-3">
<h3 class="justify-content-center align-items-center" style="text-align:center;padding:10px;">ADMIN PANEL</h3>
<p class="tables" style="text-align:center;padding:5px">
<?php
  while($row = mysqli_fetch_array($result)){
	  ?>
<b><a href="../public/admin_panel.php?table=<?php echo $row['0'];?>"><?php echo $row['0']; ?><br></a></b>
<?php
   }
?>
</p>
</div>
<div class="col-md-9">
<br>
<table border="2" cellpadding="5">
<?php
 $query1="SHOW COLUMNS FROM $table" ;
  $query2="SELECT * FROM $table";
 $result1=mysqli_query($con,$query1);
 $result2=mysqli_query($con,$query2);
?>
<tr>
<?php
foreach($result1 as $row1)
{
	?>
<td><?php echo $row1['Field']; ?></td>
<?php
}
?>
<td>Edit</td>
<td>Delete</td>
</tr>

<?php
foreach($result2 as $row2)
{
?>
<tr>
<?php
$increment=1;	
foreach($result1 as $row1)
{
	if($increment==1)
	{
	 $table_id=$row1['Field'];
	}
	?>
<td><?php echo $row2[$row1['Field']] ?></td>
<?php
$increment++;
}
?>
<td><a href="admin_panel.php?edit=<?php echo $row2[$table_id];?>&tableedit=<?php echo $table; ?>&table-id=<?php echo $table_id; ?>"><i class="fa fa-edit"></a></td>
<td><a href="admin_panel.php?delete=<?php echo $row2[$table_id];?>&tableedit=<?php echo $table; ?>&table-id=<?php echo $table_id; ?>"><i class="fa fa-remove"></a></td>
</tr>
<?php
}
?>

</table>
</div>
</div>
<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-5">
<button style="border-radius:12px;background-color:green;padding:5px;" onClick="location.href='admin-add-new.php'">Add New</button>
</div>
</div>
	 <script>
document.getElementById("cancel").onClick=function(){
	location.href="../public/index.php";
};
</script>

