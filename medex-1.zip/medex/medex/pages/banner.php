<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	$query="SELECT * FROM tbl_banner;";
  $result=mysqli_query($con,$query);
   while($row = mysqli_fetch_array($result)){
  ?>
   <section class="hero-wrap js-fullheight" style="background-image: url('../images/<?php echo $row['banner_image'];  ?>');" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-center justify-content-end" data-scrollax-parent="true">
				<div class="col-lg-6 ftco-animate">
					<div class="mt-5">
						<h1 class="mb-4">The Most Valuable Thing is Your Health</h1>
						<p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
						<div class="row">
							<div class="col-md-7 col-lg-10">
								<div class="appointment-form-intro ftco-animate">
									<div class="d-flex">
										<div class="form-group">
											<div class="form-field">
												<div class="select-wrap">
													<div class="icon"><span class="fa fa-chevron-down"></span></div>
													<select name="" id="" class="form-control">
														<option value="">Select Department</option>
														<option value="">Neurology</option>
														<option value="">Cardiology</option>
														<option value="">X-Ray</option>
														<option value="">Dental</option>
														<option value="">Ophthalmology</option>
														<option value="">Other Services</option>
													</select>
												</div>
											</div>
										</div>
										<div class="form-group">
<input type="submit" value="Book Appointment" class="btn-custom form-control py-3 px-4" data-toggle="modal" data-target="#myModal">
</div>


									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
   }
	?>
