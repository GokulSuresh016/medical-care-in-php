<?php
 $con=new mysqli('localhost','root','','db_medex1') or die("Unable to connect");
	$query="SELECT * FROM tbl_services";
  $result=mysqli_query($con,$query);
 ?>
<section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-2 bg-light">
		<div class="container">
			<div class="row d-flex">
				<div class="col-md-12 py-5">
					<div class="py-lg-5">
						<div class="row justify-content-center pb-5">
							<div class="col-md-7 heading-section ftco-animate">
								<h2 class="mb-3">Our Services <span>Medex</span></h2>
							</div>
						</div>
						</div>
				</div>
				</div>
		</div>
		<div class="container">
						<div class="row">
						<?php
						while($row = mysqli_fetch_array($result))
						{
							?>
							<div class="col-md-12 col-lg-6 d-flex align-self-stretch ftco-animate">
								<div class="media block-6 services d-flex">
									<div class="icon justify-content-center align-items-center d-flex"><span class="flaticon-<?php echo $row['service_icon'];?>"></span></div>
									<div class="media-body pl-md-4">
										<h3 class="heading mb-3"><?php echo $row['service_title'];?></h3>
											<p><?php echo $row['service_description'];  ?></p>
									</div>
								</div>      
							</div>
<?php
}
?>							
						</div>
						</div>
					
	</section>
